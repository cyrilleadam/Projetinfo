/*import java.util.*;
public class Pioche {
	
	private int index = 0;
	
	//Melange aleatoirement les diff�rents terrains
	/*public List<Domino> dominos = new ArrayList<>(Arrays.asList(
			new Domino(false, 1, Terrain.Champ, 0, Terrain.Champ, 0),
			new Domino(false, 2, Terrain.Champ, 0, Terrain.Champ, 0),
			new Domino(false, 3, Terrain.Foret, 0, Terrain.Foret, 0),
			new Domino(false, 4, Terrain.Foret, 0, Terrain.Foret, 0),
			new Domino(false, 5, Terrain.Foret, 0, Terrain.Foret, 0),
			new Domino(false, 6, Terrain.Foret, 0, Terrain.Foret, 0),
			new Domino(false, 7, Terrain.Mer, 0, Terrain.Mer, 0),
			new Domino(false, 8, Terrain.Mer, 0, Terrain.Mer, 0),
			new Domino(false, 9, Terrain.Mer, 0, Terrain.Mer, 0),
			new Domino(false, 10, Terrain.Prairie, 0, Terrain.Prairie, 0),
			new Domino(false, 11, Terrain.Prairie, 0, Terrain.Prairie, 0),
			new Domino(false, 12, Terrain.Mine, 0, Terrain.Mine, 0),
			new Domino(false, 13, Terrain.Champ, 0, Terrain.Foret, 0),
			new Domino(false, 14, Terrain.Champ, 0, Terrain.Mer, 0),
			new Domino(false, 15, Terrain.Champ, 0, Terrain.Prairie, 0),
			new Domino(false, 16, Terrain.Champ, 0, Terrain.Mine, 0),
			new Domino(false, 17, Terrain.Foret, 0, Terrain.Mer, 0),
			new Domino(false, 18, Terrain.Foret, 0, Terrain.Prairie, 0),
			new Domino(false, 19, Terrain.Champ, 1, Terrain.Foret, 0),
			new Domino(false, 20, Terrain.Champ, 1, Terrain.Mer, 0),
			new Domino(false, 21, Terrain.Champ, 1, Terrain.Prairie, 0),
			new Domino(false, 22, Terrain.Champ, 1, Terrain.Mine, 0),
			new Domino(false, 23, Terrain.Champ, 1, Terrain.Montagne, 0),
			new Domino(false, 24, Terrain.Foret, 1, Terrain.Champ, 0),
			new Domino(false, 25, Terrain.Foret, 1, Terrain.Champ, 0),
			new Domino(false, 26, Terrain.Foret, 1, Terrain.Champ, 0),
			new Domino(false, 27, Terrain.Foret, 1, Terrain.Champ, 0),
			new Domino(false, 28, Terrain.Foret, 1, Terrain.Mer, 0),
			new Domino(false, 29, Terrain.Foret, 1, Terrain.Prairie, 0),
			new Domino(false, 30, Terrain.Mer, 1, Terrain.Champ, 0),
			new Domino(false, 31, Terrain.Mer, 1, Terrain.Champ, 0),
			new Domino(false, 32, Terrain.Mer, 1, Terrain.Foret, 0),
			new Domino(false, 33, Terrain.Mer, 1, Terrain.Foret, 0),
			new Domino(false, 34, Terrain.Mer, 1, Terrain.Foret, 0),
			new Domino(false, 35, Terrain.Mer, 1, Terrain.Foret, 0),
			new Domino(false, 36, Terrain.Champ, 0, Terrain.Prairie, 1),
			new Domino(false, 37, Terrain.Mer, 0, Terrain.Prairie, 1),
			new Domino(false, 38, Terrain.Champ, 0, Terrain.Mine, 1),
			new Domino(false, 39, Terrain.Prairie, 0, Terrain.Mine, 1),
			new Domino(false, 40, Terrain.Montagne, 1, Terrain.Champ, 0),
			new Domino(false, 41, Terrain.Champ, 0, Terrain.Prairie, 2),
			new Domino(false, 42, Terrain.Mer, 0, Terrain.Prairie, 2),
			new Domino(false, 43, Terrain.Champ, 0, Terrain.Mine, 2),
			new Domino(false, 44, Terrain.Prairie, 0, Terrain.Mine, 2),
			new Domino(false, 45, Terrain.Montagne, 2, Terrain.Champ, 0),
			new Domino(false, 46, Terrain.Mine, 0, Terrain.Montagne, 2),
			new Domino(false, 47, Terrain.Mine, 0, Terrain.Montagne, 2),
			new Domino(false, 48, Terrain.Champ, 0, Terrain.Montagne, 3)));
	
	
	
	//Contructeur
	Pioche() {
		Collections.shuffle(dominos);
		afficher();
	}
	
	public void afficher() {
		for(int i=0; i<dominos.size(); i++ ) {
			System.out.println(dominos.get(i).numero);
		}
	}

	//Recupere les trois premieres cartes de la pile
	public List<Domino> distribuer(){
		if(index +3 > dominos.size()) {
			return new ArrayList<Domino>();
		}
		List<Domino> pioche = dominos.subList(index, index+3);
		index = index + 3;
		return pioche;
	}

}*/
