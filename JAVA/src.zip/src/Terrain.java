public enum Terrain {
	//initialisation des diff�rents terrains
	Foret, Champ, Prairie, Mine, Montagne, Mer; 
	public String toString() {
		switch(this ) {
		case Foret:
			return("Foret");
		case Champ:
			return("Champ");
		case Prairie:
			return("Prairie");
		case Mine:
			return("Mine");
		case Montagne:
			return("Montagne");
		case Mer:
			return("Mer");
		default:
			return("error");
				
		}
	}
}