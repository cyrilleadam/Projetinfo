import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import edu.princeton.cs.introcs.StdDraw;


public class Main {
	
	
	public static void main(String[] args) {
		//feature doublbuffering
		
		Jeu jeu = new Jeu();
		jeu.jouer();
		
	}
}
