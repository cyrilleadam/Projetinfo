import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class ListDomino {
	List<Domino> listeDomino;
	String dataDomi[] = new String[5];
public static final String FILE_PATH_DOMINO = "./DominoList/dominos.csv";
	
	


	public void ReadFile(String filename) {
		Path path = Paths.get(filename);

		try (BufferedReader br = Files.newBufferedReader(path, Charset.forName("UTF-8"))) {

			br.readLine();
			for (String line = br.readLine(); line != null; line = br.readLine()) {
				dataDomi = line.split(",");
				Domino domi = new Domino(false ,Integer.parseInt(dataDomi[4]), dataDomi[1], Integer.parseInt(dataDomi[0]),
						dataDomi[3], Integer.parseInt(dataDomi[2]));
				
				listeDomino.add(domi);
			}
		} catch (IOException e) {
			System.err.println(e);
		}
	}
	private int index = 0;
	
	
	
	public ListDomino() {
		listeDomino = new ArrayList<Domino>();
		
		ReadFile(FILE_PATH_DOMINO);
		Collections.shuffle(listeDomino);
		afficher();
	}
	
	public void afficher() {
		for(int i=0; i<listeDomino.size(); i++ ) {
			System.out.println(listeDomino.get(i).numero);
		}
	}

	//Recupere les trois premieres cartes de la pile
	public List<Domino> distribuer(){
		if(index +3 > listeDomino.size()) {
			return new ArrayList<Domino>();
		}
		List<Domino> ListDomino = listeDomino.subList(index, index+3);
		index = index + 3;
		return ListDomino;
	}
}
